package alluxio.client.file.cache;

public class UnlockTask extends LockTask{
  public UnlockTask() {
    super(null, -1);
  }

  public void readLock(int index) {

  }

  public void readUnlock(int index) {

  }

  public void writeLock(int index) {

  }

  public void unlockAllWriteLocks() {

  }

  public void unlockAllReadLocks() {

  }

}
