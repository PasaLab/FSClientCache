package alluxio.client.file.cache.submodularLib;

public interface Element {

  //public T union(T e);

}
