package alluxio.client.file.cache.submodularLib.cacheSet;

import alluxio.client.file.cache.CacheUnit;

public class CacheSamplingUtil {

  public static void reservoirSampling(CacheSet baseSet, CacheUnit unit) {

  }
}
