package alluxio.client.file.cache.struct;

public interface Node {
}
